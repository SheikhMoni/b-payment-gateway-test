package com.selenium.mavenit.training;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

public class TestSuite {
    public static WebDriver driver;

    @Before
    public void openingBrowser() {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get("http://www.argos.co.uk");
        driver.manage()
                .timeouts()
                .implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void searchTest() throws InterruptedException {
        driver.findElement(By.name("searchTerm")).sendKeys("mac");
    }
    //@After
    // public void closeBrowser(){
    //  driver.quit();
    //}

}
